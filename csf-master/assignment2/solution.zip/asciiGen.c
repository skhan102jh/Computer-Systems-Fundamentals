#include <unistd.h>
int main(void) {
for (int i = 0; i < 256; i++) {
  char  tempString[2];
  tempString[0] = (char) i;
  tempString[1] = '\0';
  int something  = write(STDOUT_FILENO, temp, 1);
  (void) something;
 }
 return 0; 
}
