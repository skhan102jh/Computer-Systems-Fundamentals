/* Sarah Khan */
/* skhan102@jh.edu */
// Unit tests for hex functions
// These tests should work for both your C implementations and your
// assembly language implementations

#include <stdio.h>
#include <stdlib.h>
#include "tctest.h"
#include "hexfuncs.h"

// test fixture object
typedef struct {
  char test_data_1[16];
} TestObjs;

// setup function (to create the test fixture)
TestObjs *setup(void) {
  TestObjs *objs = malloc(sizeof(TestObjs));
  strcpy(objs->test_data_1, "Hello, world!\n");
  return objs;
}

// cleanup function (to destroy the test fixture)
void cleanup(TestObjs *objs) {
  free(objs);
}

// Prototypes for test functions

void testFormatOffset(TestObjs *objs);
void testFormatByteAsHex(TestObjs *objs);

void testHexToPrintable(TestObjs *objs);

// SARAH'S TESTS
void sarahTestFormatByteAsHex();
void sarahTestHexToPrintable();
void sarahTestFormatOffset();
// READ AND WRITE TESTS
/*
void testHexReadSmall();
void testHexReadEmpty();
void testHexRead16();

void testHexReadMany(); 
*/

int main(int argc, char **argv) {
  if (argc > 1) {
    tctest_testname_to_execute = argv[1];
  }

  TEST_INIT();
  
  TEST(testFormatOffset);
  TEST(testFormatByteAsHex);
  
  TEST(testHexToPrintable);
  
  // SARAH'S ADDITIONAL TESTS
  TEST(sarahTestFormatOffset);
  TEST(sarahTestFormatByteAsHex);
  TEST(sarahTestHexToPrintable);
  // READ AND WRITE TESTS
  /*
  TEST(testHexReadSmall);
  TEST(testHexReadEmpty);
  TEST(testHexRead16);
  
  TEST(testHexReadMany); 
  */
  TEST_FINI();

  return 0;
}

void testFormatOffset(TestObjs *objs) {
  (void) objs; // suppress warning about unused parameter
  char buf[16];
  hex_format_offset(1L, buf);
  ASSERT(0 == strcmp(buf, "00000001"));

}
 void sarahTestFormatOffset() {
   char buf[16];

   // TESTING INVALID INPUT 
  /* NEED TO FIGURE OUT HOW TO CHECK IF SBUF SIZE IS BIG ENOUGH
   // Using a char array that isn't long enough
   char invalid[15];
   hex_format_offset(0, invalid);
   ASSERT('\0' == invalid[0]);
   */
   // Using a negative long parameter
   /*
   hex_format_offset(-1, buf);
   ASSERT('\0' == buf[0]);
   */

  // TESTING EDGE CASES 
 
  hex_format_offset(0, buf);
  ASSERT(0 == strcmp(buf, "00000000"));
  // 4294967295 is the largest representable number for an offset
  hex_format_offset(4294967295, buf);
  ASSERT(0 == strcmp(buf, "ffffffff"));
  
  // TESTING RANDOM NUMBERS WITHIN VALID INPUT RANGE
  hex_format_offset(509549209, buf);
  ASSERT(0 == strcmp(buf, "1e5f1a99"));
  hex_format_offset(968574533, buf);
  ASSERT(0 == strcmp(buf, "39bb4645"));
  hex_format_offset(219034601, buf);
  ASSERT(0 == strcmp(buf, "0d0e33e9"));
  hex_format_offset(270583387, buf);
  ASSERT(0 == strcmp(buf, "1020c65b"));
 }

void testFormatByteAsHex(TestObjs *objs) {
  char buf[16];
  hex_format_byte_as_hex(objs->test_data_1[0], buf);
  ASSERT(0 == strcmp(buf, "48"));
}

void sarahTestFormatByteAsHex() {

  char buf[16];
  // TESTING INVALID VALUES 
  /*
  hex_format_byte_as_hex(-1, buf);
  ASSERT(buf[0] == '\0'); */
  /*
  hex_format_byte_as_hex(256, buf);
  ASSERT(buf[0] == '\0');*/

  // TESTING LEGAL VALUES THAT REMAIN UNCHANGED
  hex_format_byte_as_hex(32, buf);
  ASSERT(0 == strcmp(buf, "20"));
  hex_format_byte_as_hex(126, buf);
  ASSERT(0 == strcmp(buf, "7e"));
  hex_format_byte_as_hex(83, buf); //S
  ASSERT(0 == strcmp(buf, "53")); 
  hex_format_byte_as_hex(101, buf); // e
  ASSERT(0 == strcmp(buf, "65"));
  hex_format_byte_as_hex(120, buf); // x
  ASSERT(0 == strcmp(buf, "78"));

  // TESTING LEGAL VALUES 
  hex_format_byte_as_hex(0, buf);
  ASSERT(0 == strcmp(buf, "00"));
  hex_format_byte_as_hex(31, buf);
  ASSERT(0 == strcmp(buf, "1f"));
  hex_format_byte_as_hex(127, buf);
  ASSERT(0 == strcmp(buf, "7f"));
  hex_format_byte_as_hex(255, buf);
  ASSERT(0 == strcmp(buf, "ff"));
}
void testHexToPrintable(TestObjs *objs) {
  ASSERT('H' == hex_to_printable(objs->test_data_1[0]));
  ASSERT('.' == hex_to_printable(objs->test_data_1[13]));
}

void sarahTestHexToPrintable() {
  /* NOTE: The long parameter is in decimal form.
  */

  // TESTING INVALID PARAMETERS
  /*
  ASSERT(-1 == hex_to_printable(-1));
  ASSERT(-1 == hex_to_printable(256)); */

  // TESTING LEGAL VALUES THAT REMAIN UNCHANGED
  // Testing the lowest unchanged value, which corresponds to "space" char
  ASSERT(' ' == hex_to_printable(32));
  // Testing the highest unchanged value, which corresponds to "~" char
  ASSERT('~' == hex_to_printable(126));
  //Test random characters between 32 and 126
  ASSERT('S' == hex_to_printable(83));
  ASSERT('e' == hex_to_printable(101));
  ASSERT('x' == hex_to_printable(120));

  // TESTING LEGAL VALUES THAT CHANGE TO PERIODS
  // Testing edge cases from 0 - 31 and 127 - 255
  ASSERT('.' == hex_to_printable(0));
  ASSERT('.' == hex_to_printable(31));
  ASSERT('.' == hex_to_printable(127));  
  ASSERT('.' == hex_to_printable(255));
}
// READ AND WRITE TESTS
// COMMENTED OUT BECAUSE YOU NEED TO ENTER COMMAND LINE ARGUMENTS FOR THEM TO PASS
/*
// Reading smallFile -> Passed
void testHexReadSmall() {
  char buf1[17];
  long numRead = hex_read(buf1);
  ASSERT(numRead == 6);
  ASSERT(0 == strcmp("Hello\n", buf1));
  hex_write_string(buf1); 
}

// Reading emptyFile -> Passed
void testHexReadEmpty() {
  char buf1[17];
  long numRead = hex_read(buf1);
  ASSERT(numRead == 0);
  ASSERT(0 == strcmp("", buf1));
  hex_write_string(buf1);
}

// Reading length16File -> Passed 
void testHexRead16() {
  char buf1[17];
  long numRead = hex_read(buf1);
  ASSERT(numRead == 16);
  ASSERT(0 == strcmp("aaaaaaaaaaaaaaaa", buf1));
  hex_write_string(buf1);
}

// Reading randomText -> Passed 
void testHexReadMany() {
  char buf1[17];
  long numRead = hex_read(buf1);
  ASSERT(numRead == 16);
  ASSERT(0 == strcmp("Sex and neglecte", buf1));
  hex_write_string(buf1);
}*/


