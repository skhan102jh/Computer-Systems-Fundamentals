// C implementation of hexdump main function
// Sarah Khan 
// skhan102@jh.edu
#include "hexfuncs.h"  // this is the only header file which may be included!

int main(void) {
  // TODO: implement the main function
  char colon[3] = {':', ' ', '\0'};
  char space[2] = {' ', '\0'};
  char newLine[2] = {'\n', '\0'};
  
  char buf[17];
  char offsetString[9];
  char hexRepString[49]; // 16 chars * 3 + \0
  char tempHex[3]; // will store the two hex digit representation 
  char formBuf[17]; // The string that replaces unprintable with '.'

  hexRepString[48] = '\0'; // end hexRepString
  int numRead = 0; // The number of bytes read in from standard input
  long offsetVal = 0; // The offset value to be printed
  numRead = hex_read(buf); 

  while (numRead > 0) {    
    // reset hexRepString 
    for (int i = 0; i < 48; i++) {
      hexRepString[i] = ' ';
    }
    for (int i = 0; i < numRead; i++) {
      long byteVal = buf[i]; // returns the ascii value of the temp char
      formBuf[i] = hex_to_printable(byteVal); // add a printable char to formBuf
      
      hex_format_byte_as_hex(byteVal, tempHex); 
      hexRepString[3 * i] = tempHex[0]; // store two digit hex rep into hexRepString
      hexRepString[3 * i + 1] = tempHex[1];
      hexRepString[3 * i + 2] = ' ';
    }
    formBuf[numRead] = '\0'; 
    hex_format_offset(offsetVal, offsetString); // get formatted offset string   
    hex_write_string(offsetString); // print out an entire formatted line...
    hex_write_string(colon);
    hex_write_string(hexRepString); 
    hex_write_string(space);
    hex_write_string(formBuf); 
    hex_write_string(newLine); 
    offsetVal += 16; // increment offset value to account for next 16 bytes
    numRead = hex_read(buf);
  }
  return 0; 
}
