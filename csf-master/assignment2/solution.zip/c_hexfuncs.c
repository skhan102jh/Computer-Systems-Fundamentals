// C implementation of hexdump functions
// Sarah Khan 
// skhan102@jh.edu
#include <unistd.h>  // this is the only system header file you may include!
#include "hexfuncs.h"

// TODO: add function implementations here
long hex_read(char data_buf[]) {
    // read in characters one at a time 
    long count = 0; 
    char temp;
    while ((count < 16) && (read(STDIN_FILENO, &temp, 1) > 0)) {
        data_buf[count] = temp; 
        //printf("Added %c in hex_read\n", temp); 
        count++;
    }
    data_buf[16] = '\0';
    return count; 
}

// Added this method to the header file
void hex_write_string(const char s[]) {
    long strLength = stringLength(s);
    int temp  = write(STDOUT_FILENO, s, strLength);
    (void) temp; // take care of warnings I think
    return;
}

/* Helper method to get a the length of a string.
@param s - the string to be measured
@return the length of the string in bytes
*/
int stringLength(const char s[]) {
    int count = 0; 
    while (s[count] != '\0') {
        count++;
    }
    return count; 
}

void hex_format_offset(long offset, char sbuf[]) {
    // HOW DO I MAKE SURE THAT SBUF HAS ENOUGH SPACE?
    if (offset < 0) {
        sbuf[0] = '\0';
        return;
    }
    char hexChars[] = "0123456789abcdef";
    for (int i = 0; i < 8; i++) {
        sbuf[7 - i] = hexChars[offset & 15];
        offset = offset >> 4;
    }
    sbuf[8] = '\0';
    return;
}


void hex_format_byte_as_hex(long byteval, char sbuf[]) {
    // make it non negative always 
    /*
    if ((bv < 0 )|| (bv > 255)) {
        sbuf[0] = '\0';
        return;
    }*/
    unsigned char bv = (unsigned char) byteval;

    // what do we do if byteval is above 126?
    char hexChars[] = "0123456789abcdef";
    for (int i = 0; i < 2; i++) {
        sbuf[1 - i] = hexChars[bv & 15];
        bv = bv >> 4;
    }
    sbuf[2] = '\0';
    return;
}

long hex_to_printable(long byteval_) {
    /*
    if (byteval < 0 || byteval > 255) {
        return -1;
    }
    */
    unsigned char byteval = byteval_; // added line to account for signed char
    if (byteval >= 32 && byteval <= 126) {
        return byteval;
    }
    else {
        return 46;
    }
}
