/*
 * Driver file for cache simulator
 * CSF Assignment 3
 * Autumn Hughes
 * ahughe36@jhu.edu
 * Liza Naydanova
 * enaydan1@jhu.edu
 */

#include "csim.h"
#include "Block.h"
#include <cmath>
#include <math.h>
#include <list>
#include <array>
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <string>

// Fix this
//using namespace std;

using std::cerr;
using std::cin;
using std::cout;
using std::endl;
using std::hex;
using std::invalid_argument;
using std::iterator;
using std::list;
using std::modf;
using std::stod;
using std::stoi;
using std::strcmp;
using std::string;

void incCounterHit(list<Block> set, Block bHit) {
    list<Block>::iterator iter;
    if (bHit.getCount() == (int) set.size() - 1) { //LRU was hit, update everything
        for (iter = set.begin(); iter != set.end(); ++iter) {
        iter->setCount((bHit.getCount() + 1) % (int) set.size());
        }
    } else if ((bHit.getCount() < (int) set.size() - 1) && (bHit.getCount() > 0)) { //Hit between LRU and MRU
        for (iter = set.begin(); iter != set.end(); ++iter) {
            if (iter->getCount() > -1 && iter->getCount() < bHit.getCount()) {
                iter->incCount();
            }
        }
        bHit.setCount(0); //new mru
    }
}

void incCounter(list<Block> set) {
    list<Block>::iterator iter;
    for (iter = set.begin(); iter != set.end(); ++iter) {
        iter->incCount();
    }
}

void evict(list<Block> set) {
    list<Block>::iterator iter;
    list<Block>::iterator yeet;
    for (iter = set.begin(); iter != set.end(); ++iter) {
        if(iter->getCount() == (int) set.size() - 1) {
            set.erase(iter);
            break;
        }
    }
    incCounter(set); //increment counters left
}



/*
 * Validate simulation parameters and run cache simulator based on file.
 * Parameters:
 *  argc - the number of command line arguments, should be 7, error otherwise
 *  argv - the command line arguments. In order, they are the executable,
 *         number of sets, associativity, bytes of memory per block,
 *         write-miss strategy, write-hit strategy, and eviction policy
 *
 * Returns:
 *  none, but simulation statistics output to stdout
 */
int main(int argc, char* argv[]) {
  // Validate parameters
  if (!valid_params(argc, argv)) {
    return 1;
  }

  unsigned sets = stoi(argv[1]);
  unsigned blocks = stoi(argv[2]); // Associativity AKA blocks per set
  unsigned bytes = stoi(argv[3]); // Bytes of memory per block


  int bigCycle = (100 * bytes) / 4;

  int loadHits = 0;
  int loadMisses = 0;
  int storeHits = 0;
  int storeMisses = 0;
  int totalLoads = 0;
  int totalStores = 0;
  int totalCycles = 0;

  string missAct = argv[4];
  bool wralloc;
  if (missAct.compare("write-allocate") == 0) {
    wralloc = true; // should not hit this line 
  } else {
    wralloc = false; // should hit this line 
  } 

  string storeAct = argv[5];
  bool wrback;
  if (storeAct.compare("write-back") == 0) {
    wrback = true; // should not hit this line 
  } else {
    wrback = false; // should hit this line 
  } 

  string evictChoice = argv[6];
  bool lru = false;
  if (evictChoice.compare("lru") == 0) {
    lru = true; // should hit this line
  } else {
    lru = false; // should not hit this line
  } 

  list<Block> *cache = new list<Block>[sets];
  list<Block>::iterator iter;
 
  for (unsigned i = 0; i < sets; i++) {
    list<Block> set;
    cache[i] = set;
  }
  bool store;
  char flag;
  bool hit;
  int throwaway;

  unsigned int index;
  unsigned int address;
  unsigned int offset = log2(bytes);
  unsigned int indexBits = log2(sets);
  unsigned int tagBits;

  while (!cin.eof()) {
    cin >> flag; // flag should get 's'
    if (cin.eof()) {
	  break;
	}

    cin >> hex >> address; // hex should get 0x0001
    cin >> throwaway;

    store = true; 
    hit = false;
    if (flag == 'l') {
      store = false; // should not hit this line
    }
    
    address = address >> offset; // getting rid of offset part
    index = address % sets; // is this correct?
    tagBits = address >> indexBits; // getting tag

    if (!store) {    // should not enter this block
      totalLoads++;
      if (cache[index].empty()) {
        hit = false;
      } else {
      for (iter = cache[index].begin(); iter != cache[index].end(); ++iter) { 
        if (iter->getTag() == (int) tagBits) {
          hit = true;
            loadHits++;
            totalCycles++;
            if (lru) {
              incCounterHit(cache[index], *iter);
            }
            break;
          }
        }
      }
      if (!hit) {
        loadMisses++;
        totalCycles += bigCycle;
        Block b(tagBits);
        if (cache[index].empty()) {
          cache[index].push_back(b);
        } else if (iter == cache[index].end() && (unsigned) cache[index].size() < blocks) { 
          incCounter(cache[index]);
        cache[index].push_back(b);
          } else {
        evict(cache[index]);
          cache[index].push_back(b);
        }
      }
            
    } else { // should enter this block
      totalStores++;
      if (cache[index].empty()) {
        hit = false; // should hit this line
      } else { // should not enter else block  
        for (iter = cache[index].begin(); iter != cache[index].end(); ++iter) {
          if (iter->getTag() == (int) tagBits) {
            hit = true;
            storeHits++;
            totalCycles++;
            if (!wrback) { //write through
              iter->changeDirt(false);
              totalCycles += bigCycle + 1;
            } else { //write back
              iter->changeDirt(true);
              totalCycles++;
            }
            if (lru) {
              incCounterHit(cache[index], *iter);
            }
            break;
          }
        }
      }
      if (!hit) { // should enter this block 
        storeMisses++;
        
        if (wralloc) { // should not enter this block 
          
          totalCycles += bigCycle + 1;
          Block b(tagBits);
            if (cache[index].empty()) {
              b.changeDirt(true);
              cache[index].push_back(b);
            } else if (iter == cache[index].end() && (unsigned) cache[index].size() < blocks) {
              //TODO Evict Blocks
              evict(cache[index]);
              cache[index].push_back(b);
            } else {
              //TODO: Update Counts mISS
              incCounter(cache[index]);
              cache[index].push_back(b);
            }
              
          }
          
        } 
        // BEGINNING OF SARAH 
        if (!wralloc) { // if no-write-allocate
          // since we missed, we should go directly to main memory 
          cout << "In desired else block" << endl;
          totalCycles += 100;
        }
        // END OF SARAH 
      }
    }

  cout << "Total loads: " << totalLoads << "\n";
  cout << "Total stores: " << totalStores << "\n";
  cout << "Load hits: " << loadHits << "\n";
  cout << "Load misses: " << loadMisses << "\n";
  cout << "Store hits: " << storeHits << "\n";
  cout << "Store misses: " << storeMisses << "\n";
  cout << "Total cycles: " << totalCycles << "\n";

  return 0;
}

/*
 * Checks whether command line arguments are valid simulation parameters
 * 
 * Parameters:
 *  argc - number of command line arguments
 *  argv - command line arguments, same as in main
 *
 * Returns:
 *  true if all the parameters are valid and in the required order, and false
 *  otherwise. Also prints parameter-specific errors to stderr when it finds an
 *  invalid parameter
 */
bool valid_params(int argc, char* argv[]) {
  // First check that 7 command line arguments are provided
  if (argc != 7) {
    cerr << "Should have exactly 7 args" << endl;
    return false;
  }
  if (!valid_num_args(argv)) {
    return false;
  }
  if (!valid_string_args(argv)) {
    return false;
  }
  // If all parameters are valid, return true
  return true;
}

/*
 * Determines whether a number is a positive power of 2
 *
 * Parameters:
 *  num - number to test, which may have a decimal
 *
 * Returns:
 *  true if the number is a power of 2 >= 1, false otherwise
 */
bool is_pos_pow_2(double num) {
  // Make sure num is not negative
  if (num < 0) {
    return false;
  }
  double exp = log2(num);
  double fractpart = 0;
  double intpart = 0;
  fractpart = modf(exp, &intpart);
  // Make sure exponent is positive and whole
  if (intpart < 0 || fractpart > 1.0e-10) {
    return false;
  }
  return true;
}

/*
 * Checks whether the numerical simulation parameters are valid
 *
 * Parameters:
 *  argv - the list of command line arguments from main
 *
 * Returns:
 *  true if all the numerical parameters are valid, false otherwise
 */
bool valid_num_args(char* argv[]) {
  // Check that argv[1] == # sets if pos pow of 2
  try {
    if (!is_pos_pow_2(stod(argv[1]))) {
      cerr << "Invalid number of sets" << endl;
      return false;
    }
  } catch (const invalid_argument& ia) {
    cerr << "Invalid number of sets" << endl;
    return false;
  }
  // Check that argv[2] == blocks/set is pos pow of 2
  try {
    if (!is_pos_pow_2(stod(argv[2]))) {
      cerr << "Invalid blocks/set" << endl;
      return false;
    }
  } catch (const invalid_argument& ia) {
    cerr << "Invalid blocks/set" << endl;
    return false;
  }
  if (!valid_bytes_per_block(argv)) {
    return false;
  }
  return true;
}

/*
 * Checks the third numerical argument as a helper to valid_num_args
 *
 * Parameters:
 *  argv - the command line arguments from main
 *
 * Returns:
 *  true if argv[3] is a postitive power of 2 and is greater than or 
 *  equal to 4, false otherwise
 */
bool valid_bytes_per_block(char* argv[]) {
  // Check that argv[3] == bytes/block is positive power of 2, >= 4
  double bytes_per_block = 0;
  try {
    bytes_per_block = stod(argv[3]);
  } catch (const invalid_argument& ia) {
    cerr << "Invalid bytes/block" << endl;
    return false;
  }
  if (!is_pos_pow_2(bytes_per_block) || bytes_per_block < 4) {
    cerr << "Invalid bytes/block" << endl;
    return false;
  }
  return true;
}

/*
 * Checks whether the string command line arguments are valid
 *
 * Parameters:
 *  argv - the command line arguments from main
 *
 * Returns:
 *  true if all the string parameters are valid, false otherwise
 */
bool valid_string_args(char* argv[]) {
  // Check write arguments
  if (!valid_write_args(argv)) {
    return false;
  }
  // Check that argv[6] is either "lru" or "fifo"
  char lru[] = "lru";
  char fifo[] = "fifo";
  try {
    if (strcmp(lru, argv[6]) != 0 && strcmp(fifo, argv[6]) != 0) {
      cerr << "Invalid eviction policy parameter" << endl;
      return false;
    }
  } catch (const invalid_argument& ia) {
    cerr << "Invalid eviction policy parameter" << endl;
    return false;
  }
  // If valid, return true
  return true;
}

/*
 * Checks whether the write parameters are valid as a heler to 
 * valid_string args
 * 
 * Parameters:
 *  argv - command line arguments from main
 *
 * Returns:
 *  true if write parameters are both valid, false otherwise
 */
bool valid_write_args(char* argv[]) {
  // Check that argv[4] is either "write-allocate" or "no-write-allocate"
  char wa[] = "write-allocate";
  char nwa[] = "no-write-allocate";
  try {
    if (strcmp(wa, argv[4]) != 0 && strcmp(nwa, argv[4]) != 0) {
      cerr << "Invalid write-miss parameter" << endl;
      return false;
    }
  } catch (const invalid_argument& ia) {
    cerr << "Invalid write-miss parameter" << endl;
    return false;
  }
  // Check that argv[5] is either "write-back" or "write-through"
  char wb[] = "write-back";
  char wt[] = "write-through";
  try {
    if (strcmp(wb, argv[5]) != 0 && strcmp(wt, argv[5]) != 0) {
      cerr << "Invalid write-hit parameter" << endl;
      return false;
    }
  } catch (const invalid_argument& ia) {
    cerr << "Invalid write-hit parameter" << endl;
    return false;
  }
  if (!valid_write_combo(argv)) {
    return false;
  }
  // If valid, return true
  return true;
}

/* Checks for the bad write combination no-write-allocate with write-back
 *
 * Parameters:
 *  argv - the command line arguments from main
 *
 * Returns:
 *  true if the combination is valid, false if it is the bad combination
 */
bool valid_write_combo(char* argv[]) {
  char nwa[] = "no-write-allocate";
  char wb[] = "write-back";
  if (strcmp(nwa, argv[4]) == 0 && strcmp(wb, argv[5]) == 0) {
    cerr << "no-write-allocate and write-back is not a valid combination" << endl;
    return false;
  }
  // If no problems above, return true
  return true;
}
