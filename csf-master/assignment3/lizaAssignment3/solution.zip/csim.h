bool valid_params(int argc, char* argv[]);
bool is_pos_pow_2(double num);
bool valid_num_args(char* argv[]);
bool valid_bytes_per_block(char* argv[]);
bool valid_string_args(char* argv[]);
bool valid_write_args(char* argv[]);
bool valid_write_combo(char* argv[]);
