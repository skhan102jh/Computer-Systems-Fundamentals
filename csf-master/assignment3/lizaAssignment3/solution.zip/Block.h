#ifndef BLOCK_H
#define BLOCK_H

class Block {
    private: 
        unsigned int tag;
        bool dirty = false;
        int counter = 0;
    public:
        Block(int tagVal) { tag = tagVal; }
        int getTag() { return tag; }
        void changeTag(unsigned int t) { tag = t; }
        bool isDirty() { return dirty; }
        void incCount() { counter++; }
        int getCount() { return counter;}
        void setCount(int val) {counter = val;} 
        void changeDirt(bool change) {
            if (change) {
                dirty = true;
            } else {
                dirty = false;
            }
        }
};

#endif // BLOCK_H
