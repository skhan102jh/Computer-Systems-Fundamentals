#ifndef CACHE_H
#define CACHE_H

class Cache {
 public:
  Cache(){}
  ~Cache(){}
};

#endif // CACHE_H
