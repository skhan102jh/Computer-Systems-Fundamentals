// Noah Hayden
// Sarah Khan 

#include "cache.h"
#include <iostream>
#include <assert.h>

using std::cout; using std::endl;

Cache::Cache(int numSets, int numBlocks, int numBytes) {
    this->numSets = numSets;
    for (int i = 0; i < this->numSets; i++) {
        Set* currSet = new Set(numBlocks, numBytes);
        Sets.push_back(currSet);
        // fill set object's blocks vector with numBlocks blocks
    }
    this->storeHits = 0;
    this->storeMisses = 0;
    this->loadHits = 0;
    this->loadMisses = 0;
    this->loads = 0;
    this->stores = 0;
    this->cycles = 0;
}

int Cache::numBytes() {
    Set* set = this->Sets[0];
    return set->Blocks[0]->numBytes;
}

bool Cache::accessAddress(int tag, int index, char repPolicy) {
    int found = find(tag, index); 
    if (found >= 0) {
        if (repPolicy == 'l') {
            this->Sets[index]->updateList(found);
        }
        this->cycles++;
        return true;
    }
    return false;
}

bool Cache::insertInEmptyBlock(int tag, int index) {
    Set* set = this->Sets[index];
    std::vector<Block*> blocks = set->Blocks;
    for (int i = 0; i < set->numBlocks; i++) {
        if (!blocks[i]->valid) { // If we find an empty block
            blocks[i]->tag = tag;
            blocks[i]->index = index;
            blocks[i]->valid = true; // Block contains information
            set->indices.push_front(i); // Add the index to the valid indices list
            this->cycles += (blocks[i]->numBytes / 4) * 100; 
            return true; // Indicate address was inserted
        }
    }
    return false; // Indicate address was not inserted
}

void Cache::replace(int tag, int index, char repPolicy) {
    Set* set = this->Sets[index];
    if (repPolicy == 'l') {
        set->replaceLRU(tag, index);
    }
    if (repPolicy == 'f') {
        set->replaceFIFO(tag, index);
    }
    return;
}

void Cache::loadAddress(int tag, int index, char repPolicy) {
    this->loads++;
    // If the address already exists, we have a load hit 
    if (accessAddress(tag, index, repPolicy)) {
        this->loadHits++; 
        return; 
    }
    this->loadMisses++;
    if (!this->insertInEmptyBlock(tag, index)) {
        replace(tag, index, repPolicy);
        // cycles where we have to replace
        this->cycles += (this->numBytes() / 4) * 100; 
        // Not sure if we are supposed to write-back to memory in some cases?
    }
    // cycles where we don't have to replace
    return;
}

void Cache::storeAddress(int tag, int index, char repPolicy, bool allocate, bool through) {
    this->stores++;

    // If the address already exists, we have a store hit 
    if (accessAddress(tag, index, repPolicy)) {
        this->storeHits++; 
        if (through) { // write-through
            this->cycles += 100;  // Write to main memory 
        }
        return; 
    }
    this->storeMisses++;
    if (!allocate) { // no-write-allocate
        // Skip cache and write the main memory 
        this->cycles += 100; 
        return;
    }
    else { // write-allocate
        // Try to store address into an empty block
        if (!insertInEmptyBlock(tag, index)) { // If there was no empty block available
            replace(tag, index, repPolicy);
            if(!through) { // write-back to main after replacement
                this->cycles += (this->numBytes() / 4) * 100; 
            }
        }
        if (through) { // write-through
                this->cycles += 100; 
        }
        return;
    }
}

int Cache::find(int tag, int index) {
    // get the vector associated with the set 
    Set* set = this->Sets[index];
    std::vector<Block*> blocks = set->Blocks;
    
    // search through the vector for the tag
    for (size_t i = 0; i < set->indices.size(); i++) {
        if ((blocks[i]->tag == tag) && (blocks[i]->valid == true)) {
            return i;
        }
    }
    return -1; 
}

void Cache::printStatistics() {
    cout << "Total loads: " << this->loads << endl;
    cout << "Total stores: " << this->stores << endl;
    cout << "Load hits: " << this->loadHits << endl;
    cout << "Load misses: " << this->loadMisses << endl;
    cout << "Store hits: " << this->storeHits << endl;
    cout << "Store misses: " << this->storeMisses << endl;
    cout << "Total cycles: " << this->cycles << endl;
    assert(this->stores == (this->storeHits  + this->storeMisses));
}

Cache::~Cache() {
    for (int i = 0; i < this->numSets; i++) {
        delete Sets[i];
    }
}
