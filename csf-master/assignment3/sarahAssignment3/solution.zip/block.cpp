// Noah Hayden
// Sarah Khan 
#include "block.h"

Block::Block(int tag, int index, int offset, int numBytes) {
    this->tag = tag; 
    this->index = index; 
    this->offset = offset;
    this->numBytes = numBytes; 
    this->valid = false;
}

Block::Block(int numBytes) {
    this->tag = -1; 
    this->index = -1; 
    this->offset = -1; 
    this->valid = false; 
    this->numBytes = numBytes;
}

//destructor
Block::~Block() {
}