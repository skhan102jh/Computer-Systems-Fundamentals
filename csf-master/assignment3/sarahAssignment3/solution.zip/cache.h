

#ifndef CACHE_H
#define CACHE_H

#include <vector>
#include "set.h"
#include "block.h"

class Cache {
    friend class Set; 
    friend class Block;
private: 
    int numSets; 
    std::vector<Set*> Sets;
    int loads;
    int stores;
    int loadHits;
    int loadMisses;
    int storeHits;
    int storeMisses;
    int cycles;

public: 
    Cache(int numSets, int numBlocks, int numBytes); 
    int find(int tag, int index);
    int load(int tag, int index, int offset, char policy);
    void store(int tag, int index, int offset, char policy, bool alloc, bool immediate);
    bool handleCacheInsertion(int tag, int index, int offset, char policy);
    int storeAT(int tag, int index, int offset, char policy);
    int storeAB(int tag, int index, int offset, char policy);
    int storeNT(int tag, int index, int offset, char policy);

    // void Cache::replace(int tag, int index, char policy);
    // bool Cache::searchForAddress(int tag, int index, char policy);
    // bool Cache::insertInEmptyBlock(int tag, int index);
    /** Returns the number of bytes per block 
    */
    int numBytes();

    /** Attempts to access an address. If the address is accessed, it is noted that it
    has been the most recently used address if necessary.
    @param tag - the tag of the address to access
    @param index - the index of the address to be accessed
    @return a boolean value that indicates whether or not the desired address exists
    */
    bool accessAddress(int tag, int index, char repPolicy); 

    /** Attempt to insert an address into the next available empty block in a given set 
    within the cache.  
    @param tag - the tag of the address to be inserted into the cache
    @param index - the index of the address to be inserted into the cache
    */
    bool insertInEmptyBlock(int tag, int index);

    /** Replaces a information within a block by inserting new information into the 
    block that should be evicted next. 
    @param tag - the tag of the address to be inserted into the cache
    @param index - the index of the address to be inserted into the cache
    @param policy - the type of replacement policy (lru or fifo) that will be used
    */
    void replace(int tag, int index, char repPolicy); 

    /** Loads the desired address into the cache. 
    @param tag - the tag of the address to be loaded
    @param index - the index of the address to be loaded
    @param repPolicy - the replacement policy to be used
    */
    void loadAddress(int tag, int index, char repPolicy);

    /** Stores the desired address into the cache if appropriate.
    @param tag - the tag of the address to be stored
    @param index - the index of the address to be stored
    @param repPolicy - the replacement policy to be used 
    @param allocate - true if write-allocate, false if no-write-allocate
    @param through - true if write-through, false if write-back
    */
    void storeAddress(int tag, int index, char repPolicy, bool allocate, bool through);

    /** Prints out the statistics regarding the loads, stores, load hits, load misses, 
    store hits, store misses, and total cycles.
    */
    void printStatistics();
    static void replaceFIFO(int tag, int index, int offset, Set* set);

    /** Destructor 
    */
    ~Cache();

};

#endif