#include <iostream>
#include <string>
#include "block.h"
#include "set.h"
#include "cache.h"
using std::cin; using std::cout; using std:: string; using std::endl; using std::hex;



long getOffset(long address, int numBitsOffset) {
    return ((1 << numBitsOffset) - 1) & address;
}

long getIndex(long address, int numBitsIndex, int numBitsOffset) {
    return ((1 << numBitsIndex) - 1) & (address >> numBitsOffset);
}

long getTag(long address, int numBitsTag) {
    return ((1 << numBitsTag) - 1) & (address >> (32 - numBitsTag));
}


/* Eventually we will be passing in a cache parameter */
void readTraces(Cache* cache, int numBitsOffset, int numBitsIndex, int numBitsTag, char policy, 
    bool alloc, bool immediate) {
    int count = 0;
    // Loop until there are no more lines to read
    char action; 
    long address;
    int garbage;
    while(cin >> action) {
        count++;
        cout << "Looping through traces" << endl;
        cin >> std::hex >> address;
        long offset = getOffset(address, numBitsOffset); 
        long index = getIndex(address, numBitsIndex, numBitsOffset);
        long tag = getTag(address, numBitsTag);
        cin >> garbage;
        // if l, call load(cache, tag, index, offset)
        if (action == 'l') {
            int loaded = cache->load(tag, index, offset, 'l');
            //cout << "Find attempt: " << cache->find(tag, index) << endl;
        }
        if (action == 's') {
            cache->store(tag, index, offset, 'l', alloc, immediate);
        }
        //parse the address into offset, index, and tag and store in cache object
    }
    cout << "Number of loops: " << count << endl;
    // Starting with 1 set, 1 block, 1 byte
}
/*
createBlockFromAddress(address, numBitsOffset, numBits all those ) {
    offset = getOffset(address, numBitsOffset)
    index = getIndex
    tag = getTag
    create a block with those offset, index, tagr
    return block
}*/



int getNumBits(int num) {
    int counter = 0;
    while (num != 1) {
        num = num >> 1;
        counter++;
    }
    return counter;
}

int main(int argc, char *argv[]) {
    //ingest command-line arguments
    int numSets = std::stoi(argv[1]); //first argument is the number of sets in the cache
    int numBlocks = std::stoi(argv[2]);
    int numBytes = std::stoi(argv[3]);
    string writeAlloc = argv[4];
    string writeThrough = argv[5];
    string policy = argv[6];
    bool alloc = (0 == writeAlloc.compare("write-allocate"));
    bool immediate = (0 == writeThrough.compare("write-through"));
    //need to determine number of bits to extract for each part of the address

    int numBitsOffset = getNumBits(numBytes);
    int numBitsIndex = getNumBits(numSets); //number of bits in the index is the power of the number of sets in the cache
    int numBitsTag = 32 - (numBitsOffset + numBitsIndex); //number of bits in the tag is the remaining bits of the 32 total
    cout << numBitsOffset << " " << numBitsIndex << " " << numBitsTag << endl;
    Cache *cache = new Cache(numSets, numBlocks, numBytes);
    readTraces(cache, numBitsOffset, numBitsIndex, numBitsTag, policy[0], alloc, immediate); //TODO: need to pass the policy here
    cache->printStatistics();
    return 0;
}