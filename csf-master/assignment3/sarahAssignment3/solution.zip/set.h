#ifndef SET_H
#define SET_H

#include <vector>
#include <queue>
#include <list>
#include "block.h"

class Set {
    friend class Cache; 

private: 
    std::vector<Block*> Blocks;
    int numBlocks;
    std::list<int> indices;
    std::queue<int> fifoIndices;

public: 
    /** Constructor to initialize a Set object 
    @param numBlocks - the number of blocks per set 
    @param bytesPerBlock - the number of bytes that each block will contain
    */
    Set(int numBlocks, int bytesPerBlock);

    /** Method that evicts the appropriate block in the set and fills that
    block with a new address. The block to be evicted will be the "first in"
    block compared to the other blocks in the set. 
    @param tag - the tag of the address to be stored
    @param index - the index of the address to be stored
    */
    void replaceFIFO(int tag, int index);

    /** Method that evicts the appropriate block in the set and fills that 
    block with a new address. The block to be evicted will be the "least recently used"
    block compared to the other blocks in the set.
    @param tag - the tag of the address to be stored
    @param index - the index of the address to be stored
    */
    void replaceLRU(int tag, int index);

    /** Method specifically for the context of using lru replacement. 
    When we try accessing an existing memory in the cache, this method 
    updates the Set object's indices list to represent the order in which 
    the blocks have been recently used. 
    @param index - the index in the Blocks vector of the block that contains
        the address that was most recently accessed
    */
    void updateList(int index);
 
    /** Destructor 
    */
    ~Set(); 
};

#endif