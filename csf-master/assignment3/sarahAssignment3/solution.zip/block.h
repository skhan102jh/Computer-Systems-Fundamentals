// Noah Hayden
// Sarah Khan 

#ifndef BLOCK_H
#define BLOCK_H

class Block {
    friend class Set;
    friend class Cache;

private: 
    int tag; 
    int index; 
    int offset; 
    int numBytes;
    bool valid;

public: 
    /** Constructor that takes address parameters to initialize a Block object. 
    @param tag - the tag of the address to be stored
    @param index - the index of the address to be stored
    @param numBytes - the number of bytes per block 
    */
    Block(int tag, int index, int offset, int numBytes); 

    /** Default constructor that is initialized to a given number of bytes. 
    @param numBytes - the number of bytes per block 
    */
    Block(int numBytes);

    /** Destructor
    */
    ~Block();


};

#endif