// Noah Hayden
// Sarah Khan 

#include "block.h"
#include "set.h"
#include <iostream>

Set::Set(int numBlocks, int bytesPerBlock) {
    this->numBlocks = numBlocks;
    for (int i = 0; i < this->numBlocks; i++) {
        Block* currBlock = new Block(bytesPerBlock);
        Blocks.push_back(currBlock);
    }
    this->indices = std::list<int>();
}

void Set::replaceFIFO(int tag, int index) {
    std::vector<Block*> blocks = this->Blocks;
    int repInd = this->indices.back(); 
    //std::cout << "Replacing by FIFO: [" << repInd << "]" << std::endl;
    blocks[repInd]->tag = tag; 
    
    blocks[repInd]->index = index; 
    this->indices.pop_back(); 
    this->indices.push_front(repInd);
}

//implementation of LRU eviction policy for the cache
void Set::replaceLRU(int tag, int index) {
    //using a doubly linked list and treating as a queue?
    std::vector<Block*> blocks = this->Blocks;
    int repInd = this->indices.back();
    //std::cout << "Replacing by LRU" << repInd << std::endl;
    blocks[repInd]->tag = tag; 
    blocks[repInd]->index = index; 
    this->indices.pop_back();
    this->indices.push_front(repInd);
}

void Set::updateList(int index) {
    //remove at the pre-existing index
    std::list<int>::iterator it;
    for (it = this->indices.begin(); it != this->indices.end(); ++it) {
        if (*it == index) {
            this->indices.erase(it);
            break;
        }
    }
    //place at the front of the list
    this->indices.push_front(index);
    
}

Set::~Set() {
    for (int i = 0; i < this->numBlocks; i++) {
        delete Blocks[i];
    }
}