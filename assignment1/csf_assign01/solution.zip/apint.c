/*
 * CSF Assignment 1
 * Arbitrary-precision integer data type
 * Function implementations
 */

#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "apint.h"
#include <math.h>

ApInt *apint_create_from_u64(uint64_t val) {
  ApInt * ai = malloc(sizeof(ApInt));
  ai->arr = malloc(sizeof(uint64_t));
  ai->length = 1;
  ai->arr[0] = val;
  return ai;
}

ApInt *apint_create_from_hex(const char *hex) {

	// Figure out the string length 
	size_t hexLength = strlen(hex);
	// Create a new ApInt object with needed length
	ApInt * ai = malloc(sizeof(ApInt));
	ai->length = ceil(hexLength / 16.0);
	ai->arr = malloc((ai->length) * sizeof(uint64_t)); 
	
	// Calculate number of elements needed in ApInt arr

	// Iterate through string to get groups of 16 characters to convert into uint64_t
	int count = 15; 
	int arrIndex = 0; 
	// create a 16 element string to store 64 bits that will be converted to uint64_t
	char tempWord[17];
	for (int i = 0; i < 16; i++) {
		tempWord[i] = '0';
	}
	tempWord[16] = '\0';
	// Start from the last character of the input parameter
	for (int d = (hexLength - 1); d >= 0; d--) {
		// Deal with one character from parameter at a time
		char tempChar = hex[d];
		if (count < 16) {
			tempWord[count] = tempChar;
			count--;
		}
		if ((count == -1) || (d == 0)) {
			uint64_t tempElement = strtoul(tempWord, NULL, 16);
			ai->arr[arrIndex] = tempElement;
			count = 15;
			// Reset the word with zeros so that strtol can deal with leading zeros
			for (int b = 0; b < 16; b++) {
				tempWord[b] = '0';
			}
			arrIndex++;	
		}
	}
	return ai;
}

void apint_destroy(ApInt *ap) {
	free(ap->arr);
	free(ap);
	//assert(0);
}

uint64_t apint_get_bits(ApInt *ap, unsigned n) {
	if (ap->length <= n) {
		return 0;
	}
	else {
		return ap->arr[n];
	}
	return 0UL;
}

int apint_highest_bit_set(ApInt *ap) {
	int currIndex = ap->length - 1;
	if ((currIndex == 0) && (ap->arr[currIndex] == 0)) {
		return -1;
	} 
	while((ap->arr[currIndex] == 0) && (currIndex >= 0)) {
		currIndex--;
	}
	if ((currIndex == 0) && (ap->arr[currIndex] == 0)) {
		return -1;
	}
	uint64_t element = ap->arr[currIndex];
	int numShifts = 0; 
	while (element != 0) {
		element = element >> 1;
		numShifts++;
	}
	numShifts--; 
	numShifts += currIndex * 64; 
	return numShifts;
}

ApInt *apint_lshift(ApInt *ap) {
	return apint_lshift_n(ap, 1);
}

ApInt *apint_lshift_n(ApInt *orig, unsigned n) {
	// Make a deep copy of the parameter so that we can shift it without changing orig
	ApInt * ap = malloc(sizeof(ApInt));
	ap->length = orig->length;
	ap->arr = malloc(ap->length * sizeof(uint64_t));
	for (size_t i = 0; i < orig->length; i++) {
		ap->arr[i] = orig->arr[i];
	}
	// Figure out measures needed to deal with elements that are fully zero
	int extraSpaces = n / 64; 
	int realShifts = n % 64;
	if (realShifts == 0) {
		ApInt * ai = malloc(sizeof(ApInt));
		ai->length = ap->length + extraSpaces;
		ai->arr = malloc(ai->length * sizeof(uint64_t));
		for (int i = 0; i < extraSpaces; i++) {
			ai->arr[i] = 0; 
		}
		for (size_t i = 0; i < ap->length; i++) {
			ai->arr[i + extraSpaces] = ap->arr[i];
		}
		return ai; 
	}
	ApInt * ai = malloc(sizeof(ApInt));
	ai->length = ap->length + 1;
  	ai->arr = malloc((ai->length) * sizeof(uint64_t));
	// Make the first element of the new array zero as we shift all elements down by 1
	ai->arr[0] = 0; 
	
	// Copy over elements with each element one index greater
	for (size_t i = 0; i < ap->length; i++) {		
		ai->arr[i + 1] = ap->arr[i]; 
	}
	for (size_t i = 0; i < ai->length; i++) {
		ai->arr[i] = ai->arr[i] >> (64 - realShifts);
	}
	// shift all the contents of the old array by n 
	for (size_t i = 0; i < ap->length; i++) {
		ap->arr[i] = ap->arr[i] << realShifts;
	}
	// combine the elements of both shifted array with the OR operation
	// only go the length of the old array because new array is longer
	for (size_t i = 0; i < ap->length; i++) {
		ai->arr[i] = ap->arr[i] | ai->arr[i];	
	}
	// if the last element of the new array is zero, get rid of the last element
	if (ai->arr[ai->length - 1] == 0) {
		//ai->arr[ai->length - 1] = NULL;
		ai->length = ai->length - 1; 
	}
	if (extraSpaces != 0) {
		ApInt * finalAi = malloc(sizeof(ApInt));
		finalAi->length = ai->length + extraSpaces;
		finalAi->arr = malloc(finalAi->length * sizeof(uint64_t)); 
		// fill the extra spaces with zeros
		for (int i = 0; i < extraSpaces; i++) {
			finalAi->arr[i] = 0;
		}
		for (size_t i = 0; i < ai->length; i++) {
			finalAi->arr[i + extraSpaces] = ai->arr[i];
		}
		return finalAi; 
	}
	apint_destroy(ap); 
	return ai;
}


char *apint_format_as_hex(ApInt *ap) {
	if ((ap->length == 1) && (ap->arr[0] == 0)) {
		char * result = malloc(2);
		result[0] = '0';
		result[1] = '\0';
		return result;
	}
	char hexString[16 * ap->length + 1];
	char alphabet[] = {'0','1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', '\0'};
	int hexStringIndex = 0; 
	
	for (size_t i = 0; i < ap->length; i++) {
		uint64_t tempNumber = ap->arr[i];
		 
		for (int w = 0; w < 16; w++) {			
			uint64_t lastFourBits = tempNumber & 15;
			tempNumber = tempNumber >> 4;
			char tempChar = alphabet[lastFourBits];
			hexString[hexStringIndex] = tempChar; 
			hexStringIndex++;
		}
		
	}
	hexString[hexStringIndex] = '\0';
	char * finalHexString = malloc(strlen(hexString) + 1);
	finalHexString[strlen(hexString)] = '\0';
	for (size_t i = 0; i < strlen(hexString); i++) {
		finalHexString[i] = hexString[strlen(hexString) - 1 - i];
	}
	
	int leadingZeros = 0;
	while (finalHexString[leadingZeros] == '0') {
		leadingZeros++;
	}
	
	char * retHexString = malloc(strlen(finalHexString) + 1 - leadingZeros);
	retHexString[strlen(finalHexString) + 1 - leadingZeros - 1] = '\0'; 
	
	for (size_t i = 0; i < strlen(finalHexString) + 1 - leadingZeros; i++) {
		retHexString[i] = finalHexString[leadingZeros + i];
	}
	
	free(finalHexString);
	return retHexString;
	free(finalHexString); 
	return finalHexString;
}

ApInt *apint_add(const ApInt *a, const ApInt *b) {
	// figure out maximum length length is larger
	size_t maxLength = 0;  
	if (a->length > b->length) {
		 maxLength = a->length;
	}
	else if (a->length < b->length) {
		maxLength = b->length;
	}
	else {
		maxLength = a->length;
	}
	
	ApInt * result = malloc(sizeof(ApInt));
	result->length = maxLength + 1;
	// Make the new array one element longer
  	result->arr = malloc((result->length) * sizeof(uint64_t));
	
	// only need to iterate through the shorter length 
	int addOne = 0; 
	for (size_t i = 0; i < maxLength; i++) {
		uint64_t elementSum = 0;
		if (i < a->length) {
			elementSum += a->arr[i];
		}
		if (i < b->length) {
			elementSum += b->arr[i];
		}
		if (addOne == 1) {
			elementSum++;
		}
		result->arr[i] = elementSum;
		if (i < a->length) {
			if (elementSum < a->arr[i]) {
				addOne = 1;
				continue;
			}
		}
		
		if (i < b->length){
			if (elementSum < b->arr[i]) {
				addOne = 1;
				continue;
			}
		}
		addOne = 0;
		
	}

	if (addOne == 1) {
		result->arr[result->length - 1] = 1;
	}
	else {
		//result->arr[result->length - 1] = NULL;
		result->length = result->length - 1;
	}
	return result;	
}


ApInt *apint_sub(const ApInt *a, const ApInt *b) {
	// make sure that a is indeed at least as big as b 
	if (apint_compare(a, b) < 0) {
		return NULL;
	}
	// create the result ApInt object that is one element longer than a
	ApInt * result = malloc(sizeof(ApInt));
	result->length = a->length + 1;
	// Make the new array one element longer
  	result->arr = malloc((result->length) * sizeof(uint64_t));
	// iterate through the both arrays, including each only when index permits
	int subOne = 0; 
	for (size_t i = 0; i < a->length; i++) {
		uint64_t elementDiff = 0; 
		if(i < a->length) {
			elementDiff += a->arr[i];
		}
		if (i < b->length) { 
			elementDiff -= b->arr[i];
		}
		if (subOne == -1) {
			elementDiff--;
		}
		result->arr[i] = elementDiff;
		if (elementDiff > a->arr[i]) {
			subOne = -1; 
		}
		else {
			subOne = 0;
		}
	}
	// if we still need to carry over a borrow, fill the last element with -1
	if (subOne == -1) {
		result->arr[result->length - 1] = -1;
	}
	else {
		//result->arr[result->length - 1] = NULL;
		result->length = result->length - 1;
	}
	return result;
}

int apint_compare(const ApInt *left, const ApInt *right) {
	int lengthDiff = left->length - right->length;
	if (lengthDiff != 0) {
		return lengthDiff;
	}
	for (int i = left->length - 1; i >=0; i--) {
		uint64_t leftTemp = left->arr[i]; 
		uint64_t rightTemp = right->arr[i];
		uint64_t elemDiff = leftTemp - rightTemp;
		// need to account for underflow
		if (elemDiff > leftTemp) {
			return -1;
		}
		
		if (elemDiff > 0) {
			return 1;
		}
	}
	// If you get through all elements and observe that they are all equal, return 0 to indicate equality
	return 0;
}

