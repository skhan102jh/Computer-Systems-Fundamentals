/*
 * CSF Assignment 1
 * Arbitrary-precision integer data type
 * Header file
 */

#ifndef APINT_H
#define APINT_H

#include <stddef.h>
#include <stdint.h>

typedef struct {
	/* TODO: representation */
  size_t length;
  uint64_t* arr;
} ApInt;

/* Constructors and destructors */
/** Creates a new ApInt object from a uint64_t value. The ApInt create will 
have exactly one array element with the value of the uint64_t parameter.
@param val - The uint64_t that will be assigned to index 0 the object's array.
*/
ApInt *apint_create_from_u64(uint64_t val);

/** Creates a new ApInt object from a string that represents the hexadecimal 
to be represented by the ApInt. This string will be dealt with in chunks of 64
bits, and each of these chunks will be assigned to uint64_t elements in the 
object's array.
@param hex - The string that is the hexadecimal representation of the number 
  to be stored. 
*/
ApInt *apint_create_from_hex(const char *hex);
void apint_destroy(ApInt *ap);

/* Operations */

/** Returns returns a chunk of 64 bits in a given element in the ap's array. 
@param ap - The ApInt object whose array contains the element that this method 
  seeks to access. 
@param n - The index ap's array that is being accessed and returned. 
@return a uint64_t object that is a base 10 representation of the number stored 
  ap's array at index n.
*/
uint64_t apint_get_bits(ApInt *ap, unsigned n);

/** The ApInt object parameter represents a number. If that number were 
represented as a binary number, the highest position that that number 
would contain is the position of the leftmost 1 in the binary representation. 
This method returns this position. 
@param ap - The ApInt object that is being examined for its highest position.
@return the highest position (leftmost) 1 in the binary number representation. 
*/
int apint_highest_bit_set(ApInt *ap);

/** Performs the bitwise operation of a single left shift on the ApInt 
paramter. This effectively multiplies the value represented by the ApInt object
by 2, and returns a pointer to an ApInt object that represents that new number.
@param ap - The ApInt whose number that it represents will be increased twofold. 
@return an ApInt parameter that represents the new value after the left shift. 
*/
ApInt *apint_lshift(ApInt *ap);

/** Performs the bitwise operatio of a left shift on the ApInt parameter the 
number of times specified by the parameter n. This effectively multiplies the 
number represented by the ApInt object by 2^n. Then returns a pointer to a an 
ApInt object that represents that new number. 
@param ap - The ApInt whose number that it represents will be multiplied by 2^n
@param n - The number of left shifts to perform on the number represented by 
  the ApInt object.
@return an ApInt pointer that represents the new value after the left shifts. 
*/
ApInt *apint_lshift_n(ApInt *ap, unsigned n);

/** Returns the value of the number represented by the ApInt as a string that
is the hexadecimal representation of that number. 
@param ap - The ApInt object that represents the number to be translated into
  a hexadecimal string. 
@return the string that is the hexadecimal representation of the number 
  represented by ap.
*/
char *apint_format_as_hex(ApInt *ap);

/** Adds the values represented by two ApInt objects together and returns the
sum as a new ApInt pointer. 
@param a - The first ApInt object whose number will be added.
@param b - The second ApInt object whose number will be added.
@return an ApInt pointer that represents the value of the sum of the two values
*/
ApInt *apint_add(const ApInt *a, const ApInt *b);

/** Subtracts the value of the second ApInt parameter from that of the first
and returns the difference as a new ApInt pointer. 
@param a - The ApInt object whose number will be subtracted from. 
@param b - The ApInt object whose number will subtract from a. 
@return an ApInt pointer that represents the difference between the two values.
*/
ApInt *apint_sub(const ApInt *a, const ApInt *b);

/** Compares the values represented by the two ApInt parameters. If left value
is greater than the right value, a negative number is returned. If the right 
value is greater than the left value, a positive number is returned. If the two
values are equal, a zero is returned. 
@param a - A pointer to the first ApInt object whose number will be compared. 
@param b - A pointer to the second ApInt object whose number will be compared. 
*/
int apint_compare(const ApInt *left, const ApInt *right);

// Helper methods
uint64_t hexStringToUInt64(char *hex);

#endif /* APINT_H */
