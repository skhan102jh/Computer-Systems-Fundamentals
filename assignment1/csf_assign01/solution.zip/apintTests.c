/*
 * Unit tests for arbitrary-precision integer data type
 *
 * These tests are by no means comprehensive.  You will need to
 * add more tests of your own!  In particular, make sure that
 * you have tests for more challenging situations, such as
 *
 * - large values
 * - adding/subtracting/comparing values with different lengths
 * - special cases (carries when adding, borrows when subtracting, etc.)
 * - etc.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "apint.h"
#include "tctest.h"

typedef struct {
	ApInt *ap0;
	ApInt *ap1;
	ApInt *ap110660361;
	ApInt *max1;
	/* TODO: add additional fields of test fixture */
	ApInt * tester1;
	ApInt * tester2;
	ApInt * tester3; 
	ApInt * large1;
	ApInt * large2; 
	ApInt * large3;
	ApInt * alpha1;

} TestObjs;

TestObjs *setup(void);
void cleanup(TestObjs *objs);

void testCreateFromU64(TestObjs *objs); // enough tests
void testHighestBitSet(TestObjs *objs); // enough tests
void testLshiftN(TestObjs *objs); //enough tests
void testCompare(TestObjs *objs); // enough tests
void testFormatAsHex(TestObjs *objs);
void testAdd(TestObjs *objs);
void testSub(TestObjs *objs);
/* TODO: add more test function prototypes */
void testCreateFromHex();
void myTestFormatAsHex();
void shiftOneToLeft(); //
void testLeftShiftOnLargeNumber();
void testLeftShift132();
void testSubLargeNumbers(); //
void testAddLargeNumbers();
void testGetHighestBits();

int main(int argc, char **argv) {
	TEST_INIT();
	
	if (argc > 1) {
		/*
		 * name of specific test case to execute was provided
		 * as a command line argument
		 */
		tctest_testname_to_execute = argv[1];
	}

	TEST(testCreateFromU64); // passed valgrind
	TEST(testHighestBitSet); // passed valgrind
	TEST(testLshiftN); // passed valgrind
	TEST(testCompare); // passed valgrind
	TEST(testFormatAsHex); // passed valgrind
	TEST(testAdd); // passed valgrind 
	TEST(testSub);
	
	/* TODO: use TEST macro to execute more test functions */
	TEST(testCreateFromHex);
	TEST(testGetHighestBits); // enough tests
	TEST(myTestFormatAsHex); // enough tests
	TEST(testSubLargeNumbers);
	TEST(testLeftShift132);
	TEST(testLeftShiftOnLargeNumber);
	TEST(shiftOneToLeft);
	TEST(testAddLargeNumbers);
	

	TEST_FINI();
}

TestObjs *setup(void) {
	TestObjs *objs = malloc(sizeof(TestObjs));
	objs->ap0 = apint_create_from_u64(0UL);
	objs->ap1 = apint_create_from_u64(1UL);
	objs->ap110660361 = apint_create_from_u64(110660361UL);
	objs->max1 = apint_create_from_u64(0xFFFFFFFFFFFFFFFFUL);
	
	/* TODO: initialize additional members of test fixture */
	objs->tester1 = apint_create_from_hex("12345678901234567");
	objs->tester2 = apint_create_from_u64(1111111111111111);
	//objs->tester3 = apint_create_from_hex("abcdefabcdefabcdefabcdef");//

	objs->large1 = apint_create_from_hex("e483ac7966b69c194b1ab482342fd358e7dfbd189e3d3c66240d3a84d99db6c23a94a4b0b680c697ff742ace4a4ed8f5494");
	objs->large2 = apint_create_from_hex("332ea5786d3487c89079debdd871bb7cdcd566c0f812f1e13");
	objs->large3 = apint_create_from_hex("1c65ea1f229592d8e7afb374b021d90b3db95ff6ae8ec7cc5fd06d24cb2b7891c65a89ac32227f234260bd032650");
	
	// exactly 16 characters = 64 bits
	objs->alpha1 = apint_create_from_hex("abcdefabcdefabcd"); 

	return objs;
}

void cleanup(TestObjs *objs) {
	apint_destroy(objs->ap0);
	apint_destroy(objs->ap1);
	apint_destroy(objs->ap110660361);
	apint_destroy(objs->max1);
	
	/* TODO: destroy additional members of test fixture */
	apint_destroy(objs->tester1);
	apint_destroy(objs->tester2);
	apint_destroy(objs->tester3);
	apint_destroy(objs->large1);
	apint_destroy(objs->large2);
	apint_destroy(objs->large3);
	apint_destroy(objs->alpha1);
	free(objs);
}

void testCreateFromU64(TestObjs *objs) {
	// THEIR TESTS
	ASSERT(0UL == apint_get_bits(objs->ap0, 0));
	ASSERT(1UL == apint_get_bits(objs->ap1, 0));
	ASSERT(110660361UL == apint_get_bits(objs->ap110660361, 0));
	ASSERT(0xFFFFFFFFFFFFFFFFUL == apint_get_bits(objs->max1, 0));
	
	// MY TESTS
	ASSERT(0x123456789017UL == apint_get_bits(objs->tester1, 0));
	ASSERT(1111111111111111UL == apint_get_bits(objs->tester2, 0)); //
}

void testHighestBitSet(TestObjs *objs) {
	ASSERT(-1 == apint_highest_bit_set(objs->ap0));
	ASSERT(0 == apint_highest_bit_set(objs->ap1));
	ASSERT(26 == apint_highest_bit_set(objs->ap110660361));
	ASSERT(63 == apint_highest_bit_set(objs->max1));

	// MY TESTS 
	ASSERT(61 == apint_highest_bit_set(objs->tester1));
	ASSERT(49 == apint_highest_bit_set(objs->tester2));
	ASSERT(95 == apint_highest_bit_set(objs->tester3));
}

void testLshiftN(TestObjs *objs) {
	ApInt *result;

	result = apint_lshift_n(objs->ap0, 17);
	ASSERT(0UL == apint_get_bits(result, 0));
	ASSERT(0UL == apint_get_bits(result, 1));
	apint_destroy(result);

	
	result = apint_lshift_n(objs->ap1, 17);
	ASSERT(0x20000UL == apint_get_bits(result, 0));
	ASSERT(0UL == apint_get_bits(result, 1));
	apint_destroy(result);
	

	result = apint_lshift_n(objs->ap110660361, 17);
	ASSERT(0xD3116120000UL == apint_get_bits(result, 0));
	ASSERT(0UL == apint_get_bits(result, 1));
	apint_destroy(result);

	// MY TESTS
	// Testing single apint_lshift 
	result = apint_lshift(objs->large1);
	ASSERT(9608932599017679144UL == apint_get_bits(result, 0));
	ASSERT(10706770247145422830UL == apint_get_bits(result, 1));
	ASSERT(12056306848884082514UL == apint_get_bits(result, 2));
	ASSERT(17844127896802477185UL == apint_get_bits(result, 3));
	ASSERT(6237563025154055419UL == apint_get_bits(result, 4));
	apint_destroy(result);
	
	result = apint_lshift(objs->large2);
	ASSERT(11145520805530450982UL == apint_get_bits(result, 0));
	ASSERT(1097708132592218011UL == apint_get_bits(result, 1));
	ASSERT(7337682166057335058UL == apint_get_bits(result, 2));
	ASSERT(6 == apint_get_bits(result, 3));
	apint_destroy(result);

	result = apint_lshift(objs->large3);
	ASSERT(18322478100514229408UL == apint_get_bits(result, 0));
	ASSERT(17375886496667034692UL == apint_get_bits(result, 1));
	ASSERT(10347230841461642838UL == apint_get_bits(result, 2));
	ASSERT(12832579921015299357UL == apint_get_bits(result, 3));
	ASSERT(2716180058936533059UL == apint_get_bits(result, 4));
	ASSERT(62448090367275UL == apint_get_bits(result, 5));
	apint_destroy(result);
	
	// Testing apint_lshift_n
	result = apint_lshift_n(objs->alpha1, 16);
	ASSERT(17270123625345515520UL == apint_get_bits(result, 0));
	ASSERT(43981UL == apint_get_bits(result, 1));
	apint_destroy(result);

	// Tests to see if the there is exactly one element added to the array that has value zero
	result = apint_lshift_n(objs->alpha1, 64);
	ASSERT(2 == result->length);
	ASSERT(0 == apint_get_bits(result, 0));
	apint_destroy(result);
}

void testCompare(TestObjs *objs) {
	/* 1 > 0 */
	ASSERT(apint_compare(objs->ap1, objs->ap0) > 0);
	/* 0 < 1 */
	ASSERT(apint_compare(objs->ap0, objs->ap1) < 0);
	/* 110660361 > 0 */
	ASSERT(apint_compare(objs->ap110660361, objs->ap0) > 0);
	/* 110660361 > 1 */
	ASSERT(apint_compare(objs->ap110660361, objs->ap1) > 0);
	/* 0 < 110660361 */
	ASSERT(apint_compare(objs->ap0, objs->ap110660361) < 0);
	/* 1 < 110660361 */
	ASSERT(apint_compare(objs->ap1, objs->ap110660361) < 0);

	// MY ADDED TEST

	ASSERT(apint_compare(objs->ap1, objs->ap1) == 0);
	ASSERT(apint_compare(apint_create_from_hex("8fbe2761b1374c41bac17f9f86efe2ca6811aafe8a7"), apint_create_from_hex("455f9005c4505521a211af0243d8ddebb8dd7bc8968b97ad73d0610dab99d2b082082")) < 0);
	ASSERT(apint_compare(apint_create_from_hex("4a8a0f061cb8422cdc6e5cc7d9721f22c5a65976c0ebd7fb3789847f7a16f3c20cceaba73aea18"), apint_create_from_hex("67cb7dc63d284030ece4577c0db715933ebd865dbe13730f7828b42aa51ee1e865b9d8914a88f88bf29d74f9e4a437aa0d9")) < 0);
	ASSERT(apint_compare(apint_create_from_hex("4a8a0f061cb8422cdc6e5cc7d9721f22c5a65976c0ebd7fb3789847f7a16f3c20cceaba73aea18"), apint_create_from_hex("4a8a0f061cb8422cdc6e5cc7d9721f22c5a65976c0ebd7fb3789847f7a16f3c20cceaba73aea18")) == 0);
}

void testFormatAsHex(TestObjs *objs) {
	char *s;
	//s = apint_format_as_hex(objs->ap0);
	//printf("in testFormatAsHex, s got: %s\n", s[0]);
	ASSERT(0 == strcmp("0", (s = apint_format_as_hex(objs->ap0))));
	free(s);
	//printf("Passed ZERO TEST\n");
	
	//ASSERT(0 == strcmp("1", (s = apint_format_as_hex(objs->ap1))));
	//free(s);
	
	ASSERT(0 == strcmp("6988b09", (s = apint_format_as_hex(objs->ap110660361))));
	free(s);
	
	//ASSERT(0 == strcmp("ffffffffffffffff", (s = apint_format_as_hex(objs->max1))));
	//free(s);
	
	
}

void testAdd(TestObjs *objs) {
	ApInt *sum;
	char *s;

	/* 0 + 0 = 0 */
	sum = apint_add(objs->ap0, objs->ap0);
	s = apint_format_as_hex(sum); // MY LINE
	//printf("The sum that s got was: %s\n", s);
	//ASSERT(0 == strcmp("0", (s = apint_format_as_hex(sum))));
	
	apint_destroy(sum);
	free(s);
	
	/* 1 + 0 = 1 */ 
	// yields two valgrind errors
	
	sum = apint_add(objs->ap1, objs->ap0);
	ASSERT(0 == strcmp("1", (s = apint_format_as_hex(sum))));
	apint_destroy(sum);
	free(s);
	

	/* 1 + 1 = 2 */
	// yield two valgrinds errors
	
	sum = apint_add(objs->ap1, objs->ap1);
	ASSERT(0 == strcmp("2", (s = apint_format_as_hex(sum))));
	apint_destroy(sum);
	free(s);
	
	


	/* 110660361 + 1 = 110660362 */
	// yields two valgrind errors
	
	sum = apint_add(objs->ap110660361, objs->ap1);
	ASSERT(0 == strcmp("6988b0a", (s = apint_format_as_hex(sum))));
	apint_destroy(sum);
	free(s);
	

	/* FFFFFFFFFFFFFFFF + 1 = 10000000000000000 */
	// yields two valgrind errors
	sum = apint_add(objs->max1, objs->ap1);
	ASSERT(0 == strcmp("10000000000000000", (s = apint_format_as_hex(sum))));
	apint_destroy(sum);
	free(s);
	
}

void testSub(TestObjs *objs) {

	ApInt *a, *b, *diff;
	char *s;
	
	/* subtracting 1 from ffffffffffffffff is fffffffffffffffe */
	diff = apint_sub(objs->max1, objs->ap1);


	ASSERT(0 == strcmp("fffffffffffffffe", (s = apint_format_as_hex(diff))));
	apint_destroy(diff);
	free(s);
	//printf("\n Passed invalid subtraction arguments.\n");

	/* subtracting 0 from 1 is 1 */
	diff = apint_sub(objs->ap1, objs->ap0);
	ASSERT(0 == strcmp("1", (s = apint_format_as_hex(diff))));
	ASSERT(0 == apint_compare(diff, objs->ap1));
	apint_destroy(diff);
	free(s);

	/* subtracting 1 from 1 is 0 */
	diff = apint_sub(objs->ap1, objs->ap1);
	ASSERT(0 == strcmp("0", (s = apint_format_as_hex(diff))));
	ASSERT(0 == apint_compare(diff, objs->ap0));
	apint_destroy(diff);
	free(s);

	/* subtracting 1 from 0 can't be represented because it is negative */
	ASSERT(NULL == apint_sub(objs->ap0, objs->ap1));

	
	/* test involving larger values */
	a = apint_create_from_hex("7e35207519b6b06429378631ca460905c19537644f31dc50114e9dc90bb4e4ebc43cfebe6b86d");
	b = apint_create_from_hex("9fa0fb165441ade7cb8b17c3ab3653465e09e8078e09631ec8f6fe3a5b301dc");
	diff = apint_sub(a, b);
	ASSERT(0 == strcmp("7e35207519b6afc4883c6fdd8898213a367d73b918de95f20766963b0251c622cd3ec4633b691",
		(s = apint_format_as_hex(diff))));
	apint_destroy(diff);
	apint_destroy(b);
	apint_destroy(a);
	free(s);
}

/* TODO: add more test functions */
void testCreateFromHex() {
	//printf("\n\nTESTING CREATE FROM HEX\n");
	//printf("TESTING WITH 7e35\n");
	//apint_create_from_hex("7e35");
	//printf("TESTING WITH 7e35207519b6afc4\n");
	//ApInt * tester = apint_create_from_hex("7e35207519b6afc4");
	//printf(" TESTING WITH 7e35207519b6afc4883c6fdd8898213a367d73b918de95f20766963b0251c622cd3ec4633b691");
	//ApInt * tester2 = apint_create_from_hex("7e35207519b6afc4883c6fdd8898213a367d73b918de95f20766963b0251c622cd3ec4633b691");
	//printf("TESTING WITH 01230123456789abcdef");
	//ApInt * tester3 = apint_create_from_hex("01230123456789abcdef");
	//apint_format_as_hex(tester3);
	//char * testWord = {'a', 'b', '\0'};
	//printf(strlen(testWord));
	//printf("START READING HERE.\n");
	//ApInt * tester4 = apint_create_from_hex("ffffffffffffffff");
	//printf("The number in the first index is %lu\n", tester4->arr[0]);
}

void testGetHighestBits() {
	ApInt * tester3 = apint_create_from_hex("01230123456789abcdef");
	ASSERT(72 == apint_highest_bit_set(tester3));
	ASSERT(119 == apint_highest_bit_set(apint_create_from_hex("a504c224c8726184a8db89d561f3af")));
	ASSERT(211 == apint_highest_bit_set(apint_create_from_hex("ddaae730b475c5d6129b5c59d8a578dcdd9b47e30b25aed75d027")));
}
void myTestFormatAsHex() {

	ASSERT(0 == strcmp("3661ca854297c3ad2efbc3bbd6f87531079857e4", apint_format_as_hex(apint_create_from_hex("3661ca854297c3ad2efbc3bbd6f87531079857e4"))));
	ASSERT(0 == strcmp("a11c9aa4394c1fff88178c2a9db1c3b484f56a245637fd03a591a038573b46500a059674c", apint_format_as_hex(apint_create_from_hex("a11c9aa4394c1fff88178c2a9db1c3b484f56a245637fd03a591a038573b46500a059674c"))));
	ASSERT(0 == strcmp("1fa76be6e3df6b73f0972fc963ad44691e2cfc4d030eb1b7c594d029", apint_format_as_hex(apint_create_from_hex("1fa76be6e3df6b73f0972fc963ad44691e2cfc4d030eb1b7c594d029"))));
	ASSERT(0 == strcmp("d3e3bfd671b053daadffe813c8878cfe13c7489b260f5d7ae7a1b4e0b7798e", apint_format_as_hex(apint_create_from_hex("d3e3bfd671b053daadffe813c8878cfe13c7489b260f5d7ae7a1b4e0b7798e"))));
}


void testAddLargeNumbers() {
	// Create two ApInt objects and check the sum 
	ApInt * a = apint_create_from_hex("641afee52358ee358c4676ec8a32025f83ed57b5b8fb3bcf5643f6987d8267e84498a6c25662c7");
	ApInt * b = apint_create_from_hex("cfb8b3d2e990c6dfd7da4d2fe62d69775f932ccd5b28d9295106b4d85e3");
	ApInt * sum = apint_add(a, b);
	char * s;
	ASSERT(0 == strcmp("641afee52358ee358c537277c7609b6bf1ead55a8bf99ea5edb9efcb4a581a75d72db72da3e8aa", (s = apint_format_as_hex(sum))));

	a = apint_create_from_hex("f02e0c0f3e9e9ed3d526c8f3");
	b = apint_create_from_hex("85c581ba75f649b09877c7ba722c58afef322c763bc0e83b72964cedaae0ce2");
	sum = apint_add(a, b);
	ASSERT(0 == strcmp("85c581ba75f649b09877c7ba722c58afef322c853ea1a92f5c803a2afd4d5d5", (s = apint_format_as_hex(sum))));
}

void testSubLargeNumbers() {
	/* Fact: 151ca661d9f1a58207bbe68c5 - 1c31e6137476fd5d9e55d3f5 = 13598800a2aa35ac2dd6894d0
	*/
	ApInt * a = apint_create_from_hex("151ca661d9f1a58207bbe68c5");
	ApInt * b = apint_create_from_hex("1c31e6137476fd5d9e55d3f5");
	ApInt * diff = apint_sub(a, b);
	char * d;
	ASSERT(0 == strcmp("13598800a2aa35ac2dd6894d0", (d = apint_format_as_hex(diff))));

	/* Fact: 6fa3da8bfcf2ce045f41ff97fd5a06c68bc27dc90cd7b3e9bc2a2036008d22248aaad1bdea2bff875bd0724c86cf032e1e9
	- 429324f2adeb7cc2d338c03419c2da2acc9d1e992b41b214684f068be0012e06658233c17ca81e3a02709a65e3a09cd4 
	= 6f9fb159adc7ef4c9314cc0bfa186a98e915b3f72344ffce9ae39b4597cf2211aa44799aae14350578304b42e070c924515
	*/
	a = apint_create_from_hex("6fa3da8bfcf2ce045f41ff97fd5a06c68bc27dc90cd7b3e9bc2a2036008d22248aaad1bdea2bff875bd0724c86cf032e1e9");
	b = apint_create_from_hex("429324f2adeb7cc2d338c03419c2da2acc9d1e992b41b214684f068be0012e06658233c17ca81e3a02709a65e3a09cd4");
	diff = apint_sub(a, b);
	
	ASSERT(0 == strcmp("6f9fb159adc7ef4c9314cc0bfa186a98e915b3f72344ffce9ae39b4597cf2211aa44799aae14350578304b42e070c924515", (d = apint_format_as_hex(diff))));
}

void testLeftShift132() {
	ApInt * tester = apint_create_from_hex("abcdef");
	ApInt *result;
	char * d;

	//result = apint_lshift_n(tester, 68);
	//printf("The actual shifted stuff: %s\n", d = apint_format_as_hex(result));
	//ASSERT(0 == strcmp("abcdef00000000000000000", (d = apint_format_as_hex(result))));
	// shift it 68 + 64 = 132 times
	result = apint_lshift_n(tester, 132);
	printf("The actual shifted stuff: %s\n", d = apint_format_as_hex(result));
		ASSERT(0 == strcmp("abcdef000000000000000000000000000000000", (d = apint_format_as_hex(result))));
	//0000000000000000
	//2af37bc00000000000000000
	//abcdef000000000000000000000000000000000 33 zeros	  actual 
	//abcdef000000000000000000000000000000000   predicted
	free(d);
	apint_destroy(tester);
	apint_destroy(result);

}

void testLeftShiftOnLargeNumber() {
	/*
	printf("Entered the desired testing method.\n");
	ApInt * tester = apint_create_from_hex("d172517b34ae51d7");
	ApInt * result = apint_lshift(tester);
	printf("%s\n", apint_format_as_hex(result));
	
	ApInt * tester2 = apint_create_from_hex("c3bd0af13cf46f61d108c27777d8a790a67de1ffac3eb56a2a36e0fca59fb3d42e7b14336ec9b3e93585652b092");
	ApInt * result2 = apint_lshift_n(tester2, 3);
	printf("%s\n", apint_format_as_hex(result2));*/
	/*
	ApInt * tester2 = apint_create_from_hex("c3bd0af13cf46f61d108c27777d8a790a67de1ffac3eb56a2a36e0fca59fb3d42e7b14336ec9b3e93585652b092");
	ApInt * result2 = apint_lshift_n(tester2, 68);
	printf("Final result;\n");
	printf("%s\n", apint_format_as_hex(result2));
	
	ApInt * tester3 = apint_create_from_hex("c3bd0af13cf46f61d108c27777d8a790a67de1ffac3eb56a2a36e0fca59fb3d42e7b14336ec9b3e93585652b092");
	ApInt * result3 = apint_lshift(tester3); 
	printf("When we left shift by 1, we get %s\n", apint_format_as_hex(result3));
	*/
	ApInt * tester4 = apint_create_from_hex("8888888888888888");
	//11111111111111110;
	ApInt * result4 = apint_lshift(tester4);
	printf("When we shift 8888888888888888 by 1 we get:%s\n", apint_format_as_hex(result4));
	printf("The elements in the index 0 of result is: %lu\n", result4->arr[0]);
	//printf("The result to my get bits is: %lu\n", apint_get_bits(result4, 0));
	//printf("The result of the left shift on 88.888 is %s\n", apint_format_as_hex(result));
	//ASSERT(1229782938247303440 == apint_get_bits(result4, 0));
}


void shiftOneToLeft() {
	ApInt * tester1 = apint_create_from_hex("1");
	ApInt * result1 = apint_lshift(tester1); 
	ASSERT(0 == strcmp("2", apint_format_as_hex(result1)));
}








